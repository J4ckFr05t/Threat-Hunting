aws s3 cp /var/log/apache2/access.log s3://all.logs.from.aws
aws s3 cp /var/www/MalDetector/ResultLog s3://all.logs.from.aws/EC2FileTypeLogs.log
